package com.lencostudio.dew;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Main2Activity extends AppCompatActivity {
    ListView listView;
    TextView tx;
    FirebaseDatabase database;
    DatabaseReference mData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.activity_main2);
        relativeLayout.setBackgroundResource(R.drawable.green);
        listView = (ListView) findViewById(R.id.lvsetting);
         tx = (TextView) findViewById(R.id.txTtile);
        database = FirebaseDatabase.getInstance();
         mData = database.getReference("message");


        final String arr[] = {  "Tác giả",
                "Gửi lời muốn nói ^-^"
                };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, arr);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        showDialog();
                        break;
                    case 1:
                        showDialog2();
                        break;
                }
            }
        });


    }

    public void showDialog ()
    {
        final android.support.v7.app.AlertDialog.Builder builder =
                new android.support.v7.app.AlertDialog.Builder(Main2Activity.this,
                        R.style.AppCompatAlertDialogStyle);
        builder.setMessage("Rồng Giật Điện - Coder Fa");
        builder.setCancelable(true);


        android.support.v7.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void showDialog2 ()
    {
        android.support.v7.app.AlertDialog.Builder dialogBuilder =
                new android.support.v7.app.AlertDialog.Builder(Main2Activity.this,
                        R.style.MyDialogTheme);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.custom_dialog, null);
        dialogBuilder.setView(dialogView);

        final EditText edt = (EditText) dialogView.findViewById(R.id.edit1);

        dialogBuilder.setTitle("Gửi lời muốn nói");
        dialogBuilder.setMessage("Nhập vào bên dưới sau đó nhấn gửi");
        dialogBuilder.setPositiveButton("Gửi", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                mData.push().setValue(edt.getText().toString());
                //do something with edt.getText().toString();

            }
        });
        dialogBuilder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                mData.push().setValue(edt.getText().toString() + "+  ahuhu"); //pass
            }
        });
        android.support.v7.app.AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }


    public void move(View view) {
        Intent intent = new Intent(Main2Activity.this, MainActivity.class);
        startActivity(intent);
    }
}
