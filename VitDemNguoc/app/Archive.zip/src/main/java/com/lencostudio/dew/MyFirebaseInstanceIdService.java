package com.lencostudio.dew;

import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by tanhoangduc on 2/4/17.
 */

public class MyFirebaseInstanceIdService extends FirebaseInstanceIdService {

}
